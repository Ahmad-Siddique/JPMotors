import React from "react";
import { Typography } from "@mui/material";
import DashboardHeader from "../components/dashboard/DashboardHeader";

const Dashboard = () => {
  return <><Typography variant="h4">Dashboard Page </Typography>
 {/* <DashboardHeader title={"hello"} description={"world"}/> */}
 </>;
};

export default Dashboard;
