import { combineReducers } from "redux";
import headerCardReducer from "./headerCardReducer";
import productReducer from "./productReducer";
import statusReducer from "./statusReducer";

const rootReducer = combineReducers({
  headerCard: headerCardReducer,
  products: productReducer,
  status: statusReducer,
});

export default rootReducer;
