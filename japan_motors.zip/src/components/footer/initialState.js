const initialState = {
      timeUsed: "0.05",
      totalArticles: 56,
      usd: "0.00",
      cf: "0.00",
      date: "24/2/2025",
  };
  
  export default initialState;
  